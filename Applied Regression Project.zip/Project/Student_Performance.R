# Setting the working directory
setwd('/Users/sanjithsivapuram/Documents/Education/University Of Michigan Dearborn/Data Science Course/Semester 3/Applied Regression/Project');

# Getting the directories
dir();

# Reading the data set
student_data <- read.csv("Student_Performance.csv", header=T);
head(student_data);

# Data Dimensions
dim(student_data)

# Data summary
summary(student_data);

# Data Pre-Processing

# Checking for null values in the dataset
colSums(is.na(student_data));

# TODO: One hot encoding for categorical variables
student_data$Extracurricular.Activities <- ifelse(student_data$Extracurricular.Activities == "Yes", 1, 0);

# Modified Data
head(student_data)

# Exploratory Data Analysis / Visualization

# Loading the Library
library(ggplot2)

# Hours Studied Student Distributiton
ggplot(student_data, aes(x = factor(`Hours.Studied`))) +
  geom_bar(fill = "#1f618d", color = "#1f618d", width = 0.5) +
  geom_text(stat = "count", aes(label = ..count..), vjust = -0.8, color = "black") +
  labs(title = "Distribution of Hours Studied",
       x = "Hours Studied",
       y = "Frequency") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
    plot.margin = margin(t = 10, r = 20, b = 10, l = 20) # Top, Right, Bottom, Left
  )

# Extracurricular Activities Student Distributiton
ggplot(student_data, aes(x = factor(`Extracurricular.Activities`))) +
  geom_bar(fill = "#34495e", color = "#34495e", width = 0.5) +
  geom_text(stat = "count", aes(label = ..count..), vjust = -0.8, color = "black") +
  labs(title = "Distribution of Extracurricular Activities",
       x = "Extracurricular Activities",
       y = "Frequency") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
    plot.margin = margin(t = 10, r = 20, b = 10, l = 20) # Top, Right, Bottom, Left
  )

# Previous Scores Student Distributiton
ggplot(student_data, aes(x = `Previous.Scores`)) +
  geom_density(fill = "#b03a2e", color = "#b03a2e", alpha=1) +
  labs(title = "Distribution of Previous Scores",
       x = "Previous Scores",
       y = "Density") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
    plot.margin = margin(t = 10, r = 20, b = 10, l = 20) # Top, Right, Bottom, Left
  )

# Performance Index Student Distributiton
ggplot(student_data, aes(x = `Performance.Index`)) +
  geom_density(fill = "#2ecc71", color = "#2ecc71", alpha=0.9) +
  labs(title = "Distribution of Performance Index",
       x = "Performance Index",
       y = "Density") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
    plot.margin = margin(t = 10, r = 20, b = 10, l = 20) # Top, Right, Bottom, Left
  )

# Previous Scores VS Performance Index
ggplot(student_data, aes(x = Previous.Scores, y = Performance.Index)) +
  geom_point(color = "#dc7633") +
  labs(title = "Previous Scores VS Performance Index",
       x = "Previous Scores",
       y = "Performance Index") +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
    plot.margin = margin(t = 10, r = 20, b = 10, l = 20) # Top, Right, Bottom, Left
  )

# Extracurricular Activities VS Performance Index
ggplot(student_data, aes(x = as.factor(Extracurricular.Activities), y = Performance.Index, fill = as.factor(Extracurricular.Activities))) +
  geom_violin(color = "NA" , alpha = 0.9) +
  labs(
    title = "Violin Plot: Extracurricular Activities vs Performance Index",
    x = "Participation in Extracurricular Activities",
    y = "Performance Index",
    fill = "Extracurricular Activity"
  ) +
  scale_fill_manual(values = c("0" = "#21618c", "1" = "#e67e22")) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
    plot.margin = margin(t = 10, r = 20, b = 10, l = 20), # Top, Right, Bottom, Left,
    legend.position = "top"
  )

# HeatMap of the Data
library(reshape2)
install.packages("corrplot")
library(corrplot)
library(RColorBrewer) # For predefined color palettes

cor_matrix <- cor(student_data)

cor_data <- melt(cor_matrix)
ggplot(cor_data, aes(Var1, Var2, fill = value)) +
  geom_tile(color = "white") +
  scale_fill_gradientn(
    colors = c("#a9cce3", "#7fb3d5", "#5499c7", "#2980b9", "#2471a3", "#1f618d", "#1a5276", "#154360"),
    limits = c(-1, 1),                  # Correlation values range from -1 to 1
    name = "Correlation"
  ) +
  geom_text(aes(label = sprintf("%.2f", value)), color = "white", size = 3) + # Add values on tiles
  theme_minimal() +
  labs(title = "Correlation Heatmap", x = "", y = "") +
  theme(
    plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
    axis.text.x = element_text(angle = 45, hjust = 1)
  )

# Package For Data Splitting
install.packages("caTools")
library(caTools)
set.seed(123)

# Split the data (80% training, 20% testing)
data_split <- sample.split(student_data$Performance.Index, SplitRatio = 0.8)

# Create training and testing datasets
train_data <- subset(student_data, data_split == TRUE)
test_data <- subset(student_data, data_split == FALSE)

# Checking if the data split is correct
nrow(train_data) + nrow(test_data) == nrow(data)  # Should return TRUE

cat("Training set size:", nrow(train_data), "\n")
cat("Testing set size:", nrow(test_data), "\n")

# Simple Linear Regression (Model 1)

# Finding the best explanatory variable
corr_data <- cor(student_data)
corr_data

# Model with the highest correlated explanatory varaible
model1_v1 <- lm(Performance.Index ~ Previous.Scores, data=train_data)
summary(model1_v1)

predictions1_v1 <- predict(model1_v1, newdata = test_data)

# Calculate R-squared
SSE_test_v1 <- sum((test_data$Performance.Index - predictions1_v1)^2)  # Sum of Squared Errors
SST_test_v1 <- sum((test_data$Performance.Index - mean(test_data$Performance.Index))^2)  # Total Sum of Squares

r_squared_test_v1 <- 1 - (SSE_test_v1 / SST_test_v1)

# Print R-squared for Model 1 V1
cat("R-squared on Testing Data For Model 1 V1:", r_squared_test_v1, "\n")

# Plot Model 1 Adequacy
plot(model1_v1)

model1_v2 <- lm(Performance.Index ~ Hours.Studied, data=train_data)
summary(model1_v2)

predictions1_v2 <- predict(model1_v2, newdata = test_data)

# Calculate R-squared
SSE_test_v2 <- sum((test_data$Performance.Index - predictions1_v2)^2)  # Sum of Squared Errors
SST_test_v2 <- sum((test_data$Performance.Index - mean(test_data$Performance.Index))^2)  # Total Sum of Squares

r_squared_test_v2 <- 1 - (SSE_test_v2 / SST_test_v2)

# Print R-squared For Model 1 V2
cat("R-squared on Testing Data For Model 1 V2:", r_squared_test_v2, "\n")

# Multiple Linear Regression (Model 2)
model2 <- lm(Performance.Index ~ Hours.Studied + Previous.Scores + Extracurricular.Activities + Sleep.Hours + Sample.Question.Papers.Practiced, data=train_data)
summary(model2)

predictions2 <- predict(model2, newdata = test_data)

# Calculate R-squared
SSE_test_2 <- sum((test_data$Performance.Index - predictions2)^2)  # Sum of Squared Errors
SST_test_2 <- sum((test_data$Performance.Index - mean(test_data$Performance.Index))^2)  # Total Sum of Squares

r_squared_test_2 <- 1 - (SSE_test_2 / SST_test_2)

# Print R-squared
cat("R-squared on Testing Data For Model 2:", r_squared_test_2, "\n")

# Plot Model 2 Adequacy
plot(model2)

# Finding the VIF based on the model 2
install.packages("car")
library(car)

vif2_data <- vif(model2)
vif2_data

# Random Forest (Model 3)
install.packages("randomForest")  # Uncomment if needed
library(randomForest)

# Fit a Random Forest model
rf_model <- randomForest(Performance.Index ~ Hours.Studied + Previous.Scores + Extracurricular.Activities + Sleep.Hours + Sample.Question.Papers.Practiced, data = train_data)
summary(rf_model)

# Predict on training data
predictions_rf_train <- predict(rf_model, newdata = train_data)

# Calculate SSE (Sum of Squared Errors)
SSE_train <- sum((train_data$Performance.Index - predictions_rf_train)^2)

# Calculate SST (Total Sum of Squares)
SST_train <- sum((train_data$Performance.Index - mean(train_data$Performance.Index))^2)

# Calculate R-squared
r_squared_train_3 <- 1 - (SSE_train / SST_train)

# Print R-squared
cat("R-squared for Training Data for Model 3:", r_squared_train_3, "\n")

# Predict on test data
predictions_rf_test <- predict(rf_model, newdata = test_data)

# Calculate SSE (Sum of Squared Errors)
SSE_test <- sum((test_data$Performance.Index - predictions_rf_test)^2)

# Calculate SST (Total Sum of Squares)
SST_test <- sum((test_data$Performance.Index - mean(test_data$Performance.Index))^2)

# Calculate R-squared
r_squared_test_3 <- 1 - (SSE_test / SST_test)

# Print R-squared
cat("R-squared for Test Data For Model 3:", r_squared_test_3, "\n")

# Plot Model 3 Adequacy
plot(rf_model)